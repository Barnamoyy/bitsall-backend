package com.bitsall;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BitsallApplication {

	public static void main(String[] args) {
		SpringApplication.run(BitsallApplication.class, args);
	}

}
